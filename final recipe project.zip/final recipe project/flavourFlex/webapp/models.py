import datetime
from django.contrib.auth.models import Group
from django.contrib.auth.models import User
from django.db import models
from django.core.validators import RegexValidator

# Create your models here.
class Admin(models.Model):
    id = models.AutoField(primary_key=True)  # Explicitly define the auto-incrementing ID
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='admin_profile')
    contact_number = models.CharField(
        max_length=15,
        validators=[
            RegexValidator(
                regex=r'^\+?[1-9]\d{1,14}$',  # E.164 phone number format
                message='Contact number must be a valid phone number (e.g., +1234567890).'
            )
        ]
    )
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Admin: {self.user.username}"


class Author(models.Model):
    id = models.AutoField(primary_key=True)  # Explicitly define the auto-incrementing ID
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='author_profile')
    description = models.TextField(
        null=True, 
        blank=True,
        validators=[
            RegexValidator(
                regex=r'^[a-zA-Z0-9\s,.-]*$',  # Alphanumeric, spaces, commas, periods, and hyphens
                message='Description contains invalid characters.'
            )
        ]
    )
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Author: {self.user.username}"

class FoodType(models.Model):
    id = models.AutoField(primary_key=True)  # Auto-incrementing primary key
    type = models.CharField(
        max_length=100,
        unique=True,
        validators=[
            RegexValidator(
                regex=r'^[a-zA-Z\s]*$',  # Letters and spaces only
                message='Food type must contain only letters and spaces.'
            )
        ]
    )
    description = models.TextField(
        blank=True,
        validators=[
            RegexValidator(
                regex=r'^[a-zA-Z0-9\s,.-]*$',  # Alphanumeric, spaces, commas, periods, and hyphens
                message='Description contains invalid characters.'
            )
        ]
    )

    def __str__(self):
        return self.type  # String representation for admin and debugging

class Recipes(models.Model):
    id = models.AutoField(primary_key=True)  # Auto-incrementing primary key
    name = models.CharField(
        max_length=200,
        validators=[
            RegexValidator(
                regex=r'^[a-zA-Z0-9\s]*$',  # Alphanumeric and spaces only
                message='Recipe name must contain only letters, numbers, and spaces.'
            )
        ],
        unique=True  # Ensures recipe names are unique
    )
    description = models.TextField(
        validators=[
            RegexValidator(
                regex=r'^[a-zA-Z0-9\s,.-]*$',  # Alphanumeric, spaces, commas, periods, and hyphens
                message='Recipe description contains invalid characters.'
            )
        ],
        default='No description provided',
    )
    duration = models.CharField(
        max_length=50,
        validators=[
            RegexValidator(
                regex=r'^[0-9]+(\s*[a-zA-Z]*)?$',  # Numeric values with optional units (e.g., "30 minutes")
                message='Duration must be a number, optionally followed by units (e.g., "30 minutes").'
            )
        ]
    )
    food_type = models.ForeignKey(
        'FoodType',  # Assuming a FoodType model exists
        on_delete=models.CASCADE,
        related_name='recipes',
        help_text="Select the type of food this recipe belongs to."
    )
    author_group = models.ForeignKey(Group, on_delete=models.CASCADE, related_name='recipes', null=True, blank=True)

    created_at = models.DateTimeField(default=datetime.datetime(2025, 1, 2))
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name

    
class UserRoleRequest(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    requested_role = models.CharField(
        max_length=50,
        validators=[
            RegexValidator(
                regex=r'^[a-zA-Z\s]*$',  # Letters and spaces only
                message='Requested role must contain only letters and spaces.'
            )
        ]
    )
    status = models.CharField(
        max_length=20,
        choices=[
            ('Pending', 'Pending'),
            ('Approved', 'Approved'),
            ('Denied', 'Denied'),
        ],
        default='Pending'
    )

    def __str__(self):
        return f"{self.user.username} - {self.requested_role} ({self.status})"

class Comment(models.Model):
    recipe = models.ForeignKey(Recipes, on_delete=models.CASCADE, related_name='comments')
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    text = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'{self.user.username} on {self.recipe.title}'
    
class DeletedAccount(models.Model):
    username = models.CharField(max_length=150)
    email = models.EmailField()
    deleted_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Deleted Account: {self.username} ({self.deleted_at})"