from django.urls import path
from . import views  # Import the views module from the current app

urlpatterns = [
    path('', views.start, name='start'),  # Home or startup page
    path('register/', views.register, name='register'),  # Registration page
    path('login/', views.login, name='login'),  # Login page
    path('dashboard/', views.dash, name='dash'),  # Dashboard page
    path('logout/', views.logout, name='logout'),  # Dashboard page
    # recipe urls
    path('add_food_type/', views.add_food_type, name='add_food_type'),
    path('add_recipe', views.add_recipe, name='add_recipe'),
    path('recipes/', views.list_recipes, name='list_recipes'),
    path('recipe_list/', views.list_recipes, name='recipe_list'),
    path('recipes/edit/<int:recipe_id>/', views.edit_recipe, name='edit_recipe'),
    path('recipes/delete/<int:recipe_id>/', views.delete_recipe, name='delete_recipe'),

    path('request-author/', views.request_author_role, name='request_author_role'),
    path('manage-roles/', views.manage_roles, name='manage_roles'),

    path('recipe/<int:recipe_id>/add_comment/', views.add_comment, name='add_comment'),
    path('recipe/<int:recipe_id>/comments/', views.show_comments, name='show_comments'),
    path('recipe/<int:recipe_id>/edit_comment/<int:comment_id>/', views.edit_comment, name='edit_comment'),
    path('recipe/<int:recipe_id>/delete_comment/<int:comment_id>/', views.delete_comment, name='delete_comment'),

    path("profile/", views.profile_view, name="profile"),
    path("profile/change-password/", views.change_password, name="change_password"),
    path("profile/delete-account/", views.delete_account, name="delete_account"),
]
