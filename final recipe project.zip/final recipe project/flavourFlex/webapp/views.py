from django.contrib.auth.models import Group
from django.shortcuts import get_object_or_404, render, redirect
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth.hashers import make_password
from django.contrib.auth import login as auth_login, authenticate, logout as auth_logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth import update_session_auth_hash


from webapp.models import Author, Comment, DeletedAccount, FoodType, Recipes, UserRoleRequest


# Landing or startup page
def start(request):
    recipes = Recipes.objects.all()
    return render(request, 'startup.html', {'recipes': recipes})


# Registration view
def register(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        confirm_password = request.POST['confirm_password']

        # Password confirmation check
        if password != confirm_password:
            messages.error(request, "Passwords do not match.")
            return redirect('register')

        # Username and email uniqueness check
        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already exists.")
            return redirect('register')

        if User.objects.filter(email=email).exists():
            messages.error(request, "Email already registered.")
            return redirect('register')

        # Create the user
        user = User.objects.create(
            username=username,
            email=email,
            password=make_password(password),  # Hash the password
        )

        # Add the user to the "User" group
        user_group, created = Group.objects.get_or_create(name='User')
        user.groups.add(user_group)

        messages.success(request, "Registration successful! Please log in.")
        return redirect('login')

    # If GET request, render the registration page
    return render(request, 'registration.html')

def login(request):
    # Check if the user is already authenticated
    if request.user.is_authenticated:
        # Redirect to the session-stored URL or default to the dashboard
        return redirect(request.session.pop('redirect_to', '/dashboard'))

    if request.method == 'POST':
        username = request.POST['name']  # 'name' input field in login form
        password = request.POST['password']  # 'password' input field in login form

        # Authenticate the user
        user = authenticate(request, username=username, password=password)

        if user is not None:
            auth_login(request, user)  # Log the user in

            # Redirect to the session-stored URL or default to the dashboard
            return redirect(request.session.pop('redirect_to', '/dashboard'))
        else:
            messages.error(request, "Invalid username or password.")
            return redirect('login')  # Redirect back to login page for retry

    # Store the intended destination in the session if provided in GET request
    if 'redirect_to' in request.GET:
        request.session['redirect_to'] = request.GET['redirect_to']

    if 'next' in request.GET:
        request.session['redirect_to'] = request.GET['next']

    return render(request, 'login.html')  # Render login page for GET request


@login_required
def dash(request):
    user = request.user
    is_admin = user.groups.filter(name="Admin").exists()
    is_author = user.groups.filter(name="Author").exists()
    is_user = user.groups.filter(name="User").exists()

    users_count = User.objects.count() if is_admin else None
    recipes_count = Recipes.objects.count()  # Replace with actual count of recipes
    author_group = Group.objects.get(name='Author')
    authors_count = author_group.user_set.count()

    # Retrieve role request and author approval messages
    role_request_message = request.session.get('role_request_message', None)
    if role_request_message:
        del request.session['role_request_message']  # Clear the message from session after showing it

    author_approved_message = request.session.get(f'author_approved_message_{user.id}')
    if author_approved_message:
        del request.session[f'author_approved_message_{user.id}']  # Clear the message after showing


    context = {
        'is_admin': is_admin,
        'is_author': is_author,
        'is_user': is_user,
        'users_count': users_count,
        'recipes_count': recipes_count,
        'authors_count': authors_count,
        'role_request_message': role_request_message,  # Add to context
        'role_approval_message': author_approved_message,  # Add to context
    }

    return render(request, 'dashboard.html', context)

@login_required
def profile_view(request):
    user = request.user
    is_admin = user.groups.filter(name="Admin").exists()
    is_author = user.groups.filter(name="Author").exists()
    is_user = user.groups.filter(name="User").exists()
    return render(request, "profile.html", {"user": request.user,'is_admin': is_admin,
        'is_author': is_author,
        'is_user': is_user})

@login_required
def change_password(request):
    user = request.user
    is_admin = user.groups.filter(name="Admin").exists()
    is_author = user.groups.filter(name="Author").exists()
    is_user = user.groups.filter(name="User").exists()
    if request.method == "POST":
        form = PasswordChangeForm(user=request.user, data=request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)  # Prevent logout after password change
            messages.success(request, "Your password was successfully updated!")
            return redirect("profile")  # Redirect to profile page
    else:
        form = PasswordChangeForm(user=request.user)

    return render(request, "change_password.html", {"form": form,'is_admin': is_admin,
        'is_author': is_author,
        'is_user': is_user})

@login_required
def delete_account(request):
    user = request.user
    is_admin = user.groups.filter(name="Admin").exists()
    is_author = user.groups.filter(name="Author").exists()
    is_user = user.groups.filter(name="User").exists()
    if request.method == 'POST':
        user = request.user
        # Save user details in DeletedAccount table
        DeletedAccount.objects.create(
            username=user.username,
            email=user.email,
        )
        
        # Remove the user from all groups
        user.groups.clear()
        
        # Delete the user
        user.delete()
        
        # Log out the user and redirect to a confirmation page or home
        messages.success(request, "Your account has been successfully deleted.")
        return redirect('home')  # Redirect to home or another page after deletion

    return render(request, 'delete_account.html',{'is_admin': is_admin,
        'is_author': is_author,
        'is_user': is_user})

# Logout view (optional)
def logout(request):
    if request.user.is_authenticated:
        auth_logout(request)
    return redirect('start')


@login_required
def request_author_role(request):
    user = request.user
    is_admin = user.groups.filter(name="Admin").exists()
    is_author = user.groups.filter(name="Author").exists()
    is_user = user.groups.filter(name="User").exists()
    if request.method == 'POST':
        # Check if there's an existing request
        existing_request = UserRoleRequest.objects.filter(user=request.user).first()

        if existing_request:
            if existing_request.status == 'Denied':
                # If the request was denied, allow resubmission by resetting the status
                existing_request.status = 'Pending'
                existing_request.save()
                request.session['role_request_message'] = 'Your request has been resubmitted successfully.'
            else:
                request.session['role_request_message'] = 'You have already submitted a request.'
        else:
            # Create a new request if none exists
            UserRoleRequest.objects.create(user=request.user, requested_role='Author')
            request.session['role_request_message'] = 'Your request has been submitted successfully.'

        return redirect('dash')  # Redirect to the dashboard
    return render(request, 'request_role.html',{'is_admin': is_admin,'is_author': is_author,'is_user': is_user})

@login_required  
def manage_roles(request):  
    user = request.user  
    is_admin = user.groups.filter(name="Admin").exists()  

    # Retrieve all pending role requests to display in the table  
    requests = UserRoleRequest.objects.filter(status='Pending')  

    if request.method == 'POST':  
        action = request.POST.get('action')  
        request_id = request.POST.get('request_id')  
        role_request = get_object_or_404(UserRoleRequest, id=request_id)  

        if action == 'approve':  
            role_request.status = 'Approved'  
            role_request.save()  

            # Add user to the "Author" group  
            author_group, _ = Group.objects.get_or_create(name='Author')  
            role_request.user.groups.add(author_group)  

            # Remove user from the "User" group  
            user_group = Group.objects.filter(name='User').first()  
            if user_group:  
                role_request.user.groups.remove(user_group)  
                
            # Set success message for approval  
            request.session['role_request_message'] = f"Role request for {role_request.user.username} has been approved successfully."  

        elif action == 'deny':  
            role_request.status = 'Denied'  
            role_request.save()  
            
            # Set success message for denial  
            request.session['role_request_message'] = f"Role request for {role_request.user.username} has been denied."  

        # Redirect to the dashboard  
        return redirect('dash')  # Assuming 'dash' is the name of your dashboard view  

    # For GET requests, render the page with the pending requests  
    return render(request, 'manage_request.html', {'is_admin': is_admin, 'requests': requests})

@login_required
def add_recipe(request, recipe_id=None):
    user = request.user
    is_admin = user.groups.filter(name="Admin").exists()
    is_author = user.groups.filter(name="Author").exists()  # Check group membership
    is_user = user.groups.filter(name="User").exists()

    # Fetch all food types to populate the dropdown
    food_types = FoodType.objects.all()

    # If editing a recipe, fetch the recipe object
    recipe = None
    if recipe_id:
        try:
            recipe = Recipes.objects.get(id=recipe_id)
        except Recipes.DoesNotExist:
            recipe = None

    if request.method == 'POST':
        # Process form data
        name = request.POST.get('name')
        description = request.POST.get('description')
        duration = request.POST.get('duration')
        food_type_id = request.POST.get('food_type')

        # Validate food type
        try:
            food_type = FoodType.objects.get(id=food_type_id)
        except FoodType.DoesNotExist:
            food_type = None

        # Ensure all required fields are provided
        if name and description and duration and food_type:
            if recipe:  # Update existing recipe
                recipe.name = name
                recipe.description = description
                recipe.duration = duration
                recipe.food_type = food_type
                recipe.save()
            else:  # Create a new recipe
                Recipes.objects.create(
                    name=name,
                    description=description,
                    duration=duration,
                    food_type=food_type
                )
            return redirect('recipe_list')  # Redirect to the recipe list
        else:
            # Show an error if any field is missing
            return render(request, 'recipe_form.html', {
                'food_types': food_types,
                'recipe': recipe,
                'is_admin': is_admin,
                'is_author': is_author,
                'is_user': is_user,
                'error': "All fields are required.",
            })

    # Render the recipe form
    return render(request, 'recipe_form.html', {
        'food_types': food_types,
        'recipe': recipe,
        'is_admin': is_admin,
        'is_author': is_author,
        'is_user': is_user,
    })



def add_food_type(request):
    if request.method == "POST":
        # Save Food Type
        type_name = request.POST['type']
        description = request.POST['description']
        FoodType.objects.create(type=type_name, description=description)
        return redirect('add_recipe')

def list_recipes(request):
    if not request.user.is_authenticated:
        # Redirect the user to the login page with 'next' set to the current page's URL
        return redirect(f'/login/?next={request.path}')
        
    user = request.user
    is_admin = user.groups.filter(name="Admin").exists()
    is_author = user.groups.filter(name="Author").exists()
    is_user = user.groups.filter(name="User").exists()

    # Check if the logged-in user is an author
    try:
        Author.objects.get(user=user)
        is_author = True
    except Author.DoesNotExist:
        pass  # User is not an author

    # Get the search query
    query = request.GET.get('q', '')  # Retrieve the search query

    # Fetch recipes based on the search query
    if query:
        # Filter recipes by name or food type (case-insensitive)
        recipes = Recipes.objects.filter(
            name__icontains=query
        )
    else:
        # Fetch all recipes if no search query is provided
        recipes = Recipes.objects.all()

    # Mark recipes that the user can edit
    for recipe in recipes:
        recipe.can_edit = is_admin or is_author
    food_type = FoodType.objects.all()  # Fetch all food types

    return render(request, 'recipe.html', {
        'recipes': recipes,
        'food_type': food_type,
        'is_admin': is_admin,
        'is_author': is_author,
        'is_user': is_user,
        'query': query  # Pass the search query to the template
    })


def edit_recipe(request, recipe_id):
    user = request.user
    is_admin = user.groups.filter(name="Admin").exists()
    is_author = user.groups.filter(name="Author").exists()
    is_user = user.groups.filter(name="User").exists()

    recipe = get_object_or_404(Recipes, id=recipe_id)

    # Check if the user is in the recipe's author group or is an admin
    if not request.user.is_superuser and recipe.author_group not in request.user.groups.all():
        messages.error(request, "You do not have permission to edit this recipe.")
        return redirect('recipe_list')  # Redirect if no permission

    # Fetch all food types to populate the dropdown
    food_types = FoodType.objects.all()

    if request.method == 'POST':
        # Process form submission for editing the recipe
        name = request.POST.get('name')
        recipe_content = request.POST.get('recipe')
        duration = request.POST.get('duration')
        food_type_id = request.POST.get('food_type')

        try:
            food_type = FoodType.objects.get(id=food_type_id)
        except FoodType.DoesNotExist:
            food_type = None

        if name and recipe_content and duration and food_type:
            # Save the updated recipe
            recipe.name = name
            recipe.description = recipe_content
            recipe.duration = duration
            recipe.food_type = food_type
            recipe.save()

            messages.success(request, "Recipe updated successfully!")
            return redirect('recipe_list')  # Redirect to the recipe list
        else:
            # If any required data is missing
            error_message = "All fields are required!"
            return render(request, 'recipe_form.html', {
                'recipe': recipe,
                'food_types': food_types,
                'error_message': error_message,
                'is_admin': is_admin,
                'is_author': is_author,
                'is_user': is_user,
            })

    return render(request, 'recipe_form.html', {
        'recipe': recipe,
        'food_types': food_types,
        'is_admin': is_admin,
        'is_author': is_author,
        'is_user': is_user,
    })

def delete_recipe(request, recipe_id):
    user = request.user
    is_admin = user.groups.filter(name="Admin").exists()
    is_author = user.groups.filter(name="Author").exists()
    is_user = user.groups.filter(name="User").exists()

    # Get the recipe object
    recipe = get_object_or_404(Recipes, id=recipe_id)

    # Check if the user is the author or an admin
    if not is_admin and recipe.author != request.user:
        messages.error(request, "You do not have permission to delete this recipe.")
        return redirect('recipe_list')  # Redirect if no permission

    # Delete the recipe
    recipe.delete()
    
    # Redirect after deletion
    return redirect('recipe_list',{is_author,is_user})

@login_required
def add_comment(request, recipe_id):
    recipe = get_object_or_404(Recipes, id=recipe_id)
    user = request.user

    # Check user roles
    is_admin = user.groups.filter(name="Admin").exists()
    is_author = user.groups.filter(name="Author").exists()
    is_user = user.groups.filter(name="User").exists()

    # Only allow users in the "User" group to add comments
    if not is_user:
        messages.error(request, "Only regular users can add comments.")
        return redirect('list_recipes')

    # Handle POST request for adding a comment
    if request.method == 'POST':
        comment_text = request.POST.get('comment')
        if comment_text:
            Comment.objects.create(recipe=recipe, user=user, text=comment_text)
            messages.success(request, "Comment added successfully!")
            return redirect('add_comment', recipe_id=recipe.id)

    # Fetch only comments by the logged-in user for display
    comments = recipe.comments.filter(user=user)

    # Render the template
    return render(request, 'add_comment.html', {
        'recipe': recipe,
        'comments': comments,
        'is_user': is_user,  # This ensures we can conditionally show content in the template
    })



@login_required
def show_comments(request, recipe_id):
    user = request.user
    is_admin = user.groups.filter(name="Admin").exists()
    is_author = user.groups.filter(name="Author").exists()
    is_user = user.groups.filter(name="User").exists()
    # Fetch the recipe object by its ID
    recipe = get_object_or_404(Recipes, id=recipe_id)

    # Filter comments related to the specific recipe
    comments = recipe.comments.all()  # Use the related_name defined in the Comment model

    return render(request, 'show_comments.html', {
        'recipe': recipe,
        'comments': comments,'is_admin': is_admin,'is_author': is_author,'is_user': is_user
    })

@login_required
def edit_comment(request, recipe_id, comment_id):
    user = request.user
    is_admin = user.groups.filter(name="Admin").exists()
    is_author = user.groups.filter(name="Author").exists()
    is_user = user.groups.filter(name="User").exists()
    comment = get_object_or_404(Comment, id=comment_id, user=request.user)
    if request.method == 'POST':
        comment_text = request.POST.get('comment')
        if comment_text:
            comment.text = comment_text
            comment.save()
        return redirect('show_comments', recipe_id=recipe_id)
    return render(request, 'edit_comment.html', {'comment': comment, 'is_admin': is_admin,'is_author': is_author,'is_user': is_user})

@login_required
def delete_comment(request, recipe_id, comment_id):
    user = request.user
    is_admin = user.groups.filter(name="Admin").exists()
    is_author = user.groups.filter(name="Author").exists()
    is_user = user.groups.filter(name="User").exists()
    comment = get_object_or_404(Comment, id=comment_id, user=request.user)
    if request.method == 'POST':
        comment.delete()
        return redirect('show_comments', recipe_id=recipe_id)
    return render(request, 'delete_comment.html', {'comment': comment,'is_admin': is_admin,'is_author': is_author,'is_user': is_user})